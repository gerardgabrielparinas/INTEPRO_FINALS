﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FINALS.Models;
using Microsoft.Data;
using Microsoft.Data.SqlClient;

namespace FINALS.Controllers
{
    public class UserLoginController : Controller
    {
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(LoginClass obj)
        {
            SqlConnection cn = new SqlConnection(@"Server=VERGIL\MSSQLSERVER2019;" +
            "Database=Intepro_Finals;Integrated Security=SSPI");
            string sqlquery = "SELECT * FROM Login WHERE Username = @UName AND Password = @pwd";
            cn.Open();
            SqlCommand cmd = new SqlCommand(sqlquery, cn);
            cmd.Parameters.AddWithValue("@UName", obj.UserName);
            cmd.Parameters.AddWithValue("@pwd", obj.Password);
            SqlDataReader dr = cmd.ExecuteReader();
            if(dr.Read())
            {
                return RedirectToAction("welcome");
            }
            else
            {
                ViewData["Message"] = "User Login Failed";
            }
            cn.Close();
            return View();
        }

        public IActionResult welcome()
        {
            return View();
        }

        public IActionResult AddAcct()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddAcct(Registration reg)
        {
            SqlConnection cn = new SqlConnection(@"Server=VERGIL\MSSQLSERVER2019;" +
            "Database=Intepro_Finals;Integrated Security=SSPI");
            string query = "INSERT INTO Login (Username, Password) VALUES (@un, @pass)";
            SqlCommand sqlcomm = new SqlCommand(query, cn);
            cn.Open();
            sqlcomm.Parameters.AddWithValue("@un", reg.Username);
            sqlcomm.Parameters.AddWithValue("@pass", reg.PassWord);
            if(reg.PassWord == reg.ConfirmPWD)
            {
                sqlcomm.ExecuteNonQuery();
                ViewData["Message2"] = "Record Inserted Successfully";
                return View();
            }
            else
            {
                ViewData["Message3"] = "Passwords do not match";
            }
            cn.Close();
            return View();
        }
    }
}
