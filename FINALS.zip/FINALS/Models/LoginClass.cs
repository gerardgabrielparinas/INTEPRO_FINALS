﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace FINALS.Models
{
    public class LoginClass
    {
        [Required(ErrorMessage ="Username is required")]
        [Display(Name ="Enter Username :")]
        public string UserName { get; set; }

        [Required(ErrorMessage ="Password is required")]
        [Display(Name ="Enter Password :")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}
