﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.ComponentModel.DataAnnotations;


namespace FINALS.Models
{
    public class Registration
    {
        [Required(ErrorMessage = "Please provide a Username")]
        [Display(Name = "Enter Username :")]
        public string Username { get; set; }

        [Required(ErrorMessage = "Please provide a password")]
        [Display(Name = "Enter Password :")]
        [DataType(DataType.Password)]
        public string PassWord { get; set; }

        [Required(ErrorMessage = "Password confirmation is required")]
        [Display(Name = "Confirm Password :")]
        [DataType(DataType.Password)]
        public string ConfirmPWD { get; set; }
    }
}
